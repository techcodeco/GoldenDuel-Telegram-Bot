// Run once: bun run webhook
const { BOT_TOKEN, PUBLIC_URL, WEBHOOK_TOKEN } = process.env
if (!BOT_TOKEN || !PUBLIC_URL || !WEBHOOK_TOKEN) {
  throw new Error('BOT_TOKEN, PUBLIC_URL and WEBHOOK_TOKEN must be set in .env')
}

const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    url: `${PUBLIC_URL}/webhook/${WEBHOOK_TOKEN}`, // Telegram passes the token back in the path
    max_connections: 100,
    drop_pending_updates: false,
    allowed_updates: ['message', 'edited_message', 'callback_query', 'my_chat_member', 'message_reaction'],
  }),
})
console.log(await res.json())
